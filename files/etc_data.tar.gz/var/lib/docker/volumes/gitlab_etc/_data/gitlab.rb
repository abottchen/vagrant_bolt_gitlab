external_url 'https://wispy-crater.delivery.puppetlabs.net'
